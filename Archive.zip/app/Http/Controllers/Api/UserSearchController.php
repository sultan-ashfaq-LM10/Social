<?php

namespace App\Http\Controllers\Api;

use App\Enums\Friends\FriendStatusEnum;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserSearchController extends Controller
{
    /**
     * Search for users
     * For simplicity sake, return users who are not friends or has pending friend request
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws \Psr\Container\ContainerExceptionInterface
     * @throws \Psr\Container\NotFoundExceptionInterface
     */
    public function index()
    {
        try {
            $name = request()->get('query') ?? '';
            if ($name === '') {
                return response()->json(collect());
            }
            $authUserId = auth()->id();
            $users = DB::select("
                SELECT users.*, friend_relationships.user_id, friend_relationships.status
                FROM users
                LEFT JOIN friends AS friend_relationships
                ON (users.id = friend_relationships.friend_id AND friend_relationships.user_id = ?)
                OR (users.id = friend_relationships.user_id AND friend_relationships.friend_id = ?)
                WHERE users.name LIKE ? and users.id != ?
            ", [ $authUserId, $authUserId, "%$name%", $authUserId]);

            $results = collect($users)->map(function($user) {
                return [
                    'user' => $user,
                    'friendRelationship' => $user->user_id ?
                        ['user_id' => $user->user_id, 'status' => FriendStatusEnum::from($user->status)->name] : null
                ];
            });

            return response()->json(
                $results
            );

            return response()->json(
                UserResource::collection($userQuery->get())
            );
        }
        catch (\Exception $exception) {
            return response()->json($exception->getMessage(), 500);
        }
    }
}
