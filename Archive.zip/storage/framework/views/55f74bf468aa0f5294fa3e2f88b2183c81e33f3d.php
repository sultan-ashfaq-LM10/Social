<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('css/app.css')); ?>">

</head>
<script>
    window.Laravel = {csrfToken: '<?php echo e(csrf_token()); ?>'};

</script>

<body>
    <div id="app">
        <transition name="slide-fade" mode="out-in">
            <router-view :auth-check="<?php echo e(Auth::check() ? 'true': 'false'); ?>"></router-view>
        </transition>
    </div>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/sultanashfaq/Web Projects/social/resources/views/vue-home.blade.php ENDPATH**/ ?>