<template>
  <section class="mt-6">
    <div class="container d-flex justify-content-center">
      <HomePosts />
    </div>
  </section>
</template>

<script>
import HomePosts from './HomeFeedPosts.vue'
export default {
  components: { HomePosts }
}
</script>
