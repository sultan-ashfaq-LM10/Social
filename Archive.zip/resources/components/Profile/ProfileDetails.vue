<template>
  <div class="columns is-mobile is-centered">
    <div class="column is-four-fifths has-background-white my-6">
<!--      <b-field label="Name">-->
<!--        <b-input value="Kevin Garvey"/>-->
<!--      </b-field>-->

    </div>
  </div>
</template>

<script>
export default {
  name: "Details"
}
</script>

<style scoped>

</style>